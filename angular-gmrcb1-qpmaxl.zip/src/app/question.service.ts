import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { QuestionDetails, QuestionDetailsResponse } from './question.constant';

@Injectable({
  providedIn: 'root',
})
export class QuestionService {
  public getQuestionDetails(): Observable<any> {
    return of({
      question: 'I am $$_$$. I have one $$_$$ and two $$_$$',
      options: ['kidney', 'dumbass', 'heart', 'tusk', 'trunk', 'tail'],
    });
  }

  public processQuestionResponse(
    rawResponse: QuestionDetailsResponse
  ): QuestionDetails {
    const questionDetails = {
      questions: rawResponse.question.split('$$_$$').filter((question) => {
        return question;
      }),
      options: rawResponse.options,
      answers: new Array(
        rawResponse.question.split('$$_$$').filter((question) => {
          return question;
        }).length
      ),
    };
    questionDetails.questions.forEach((quest, i) => {
      questionDetails['answers'][i] = [];
    });

    return questionDetails;
  }
}
