import { Component, OnInit } from '@angular/core';
import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from '@angular/cdk/drag-drop';
import { QuestionService } from './question.service';
import { QuestionDetails, QuestionDetailsResponse } from './question.constant';
import { timeout } from 'rxjs/operators';

/**
 * @title Drag&Drop connected sorting group
 */
@Component({
  selector: 'cdk-drag-drop-connected-sorting-group-example',
  templateUrl: 'cdk-drag-drop-connected-sorting-group-example.html',
  styleUrls: ['cdk-drag-drop-connected-sorting-group-example.css'],
})
export class CdkDragDropConnectedSortingGroupExample implements OnInit {
  constructor(private questionService: QuestionService) {}

  public questionDetails: QuestionDetails;

  public ngOnInit(): void {
    this.getQuestionDetails();
  }

  public trackByMethod(index: number): number {
    return index;
  }

  private getQuestionDetails = () => {
    const successHandler = (resp: QuestionDetailsResponse) => {
      this.questionDetails = this.questionService.processQuestionResponse(resp);
      console.log(this.questionDetails);
    };

    const errorHandler = () => {};

    this.questionService
      .getQuestionDetails()
      .subscribe(successHandler, errorHandler);
  };

  drop(event: CdkDragDrop<string[]>) {
    debugger;
    if (event.previousContainer === event.container) {
      return;
    }

    const allowTheMove = () => {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    };

    const swap = () => {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
      transferArrayItem(
        event.container.data,
        event.previousContainer.data,
        event.currentIndex + 1,
        event.previousIndex
      );
    };

    if (event.container.data.length === 0) {
      allowTheMove();
    } else {
      swap();
    }
  }
}
