export interface EntryKeyValue {
  key: string;
  value: string;
}