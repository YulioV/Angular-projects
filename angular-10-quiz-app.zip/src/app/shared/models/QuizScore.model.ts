export interface QuizScore {
  quizId: string;
  attemptDateTime: Date;
  score: number;
  totalQuestions: number;
}
