export interface Resource {
  title: string;
  url: string;
  host: string;
}
type Resources = Resource[];
