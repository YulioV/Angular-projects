export interface QuizSelectionParams {
  status: string;
  startedQuizId: string;
  continueQuizId: string;
  completedQuizId: string;
  quizCompleted: boolean;
}
