import {Component} from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';

/**
 * @title Drag&Drop connected sorting
 */
@Component({
  selector: 'cdk-drag-drop-connected-sorting-example',
  templateUrl: 'cdk-drag-drop-connected-sorting-example.html',
  styleUrls: ['cdk-drag-drop-connected-sorting-example.css'],
})
export class CdkDragDropConnectedSortingExample {
  todo = [
    {text:'Get to work',order:0},
    {text:'Pick up groceries',order:1},
    {text:'Go home',order:2},
    {text:'Fall asleep',order:3}
  ];

  done = [
    {text:'Get up',order:0},
    {text:'Brush teeth',order:1},
    {text:'Take a shower',order:2},
    {text:'Check e-mail',order:3},
    {text:'Walk dog',order:4}
  ];

  drop(event: CdkDragDrop<any[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
      event.previousContainer.data.forEach((x,index)=>{
        x.order=index
      })
    }
    event.container.data.forEach((x,index)=>{
      x.order=index
    })
  }
}


/**  Copyright 2019 Google LLC. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */