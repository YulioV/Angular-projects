import {
  Component,
  OnInit,
  ViewChildren,
  QueryList,
  ElementRef,
  AfterViewInit,
  Renderer2,
  OnDestroy,
  DoCheck
} from "@angular/core";
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";

@Component({
  selector: "my-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit, AfterViewInit, OnDestroy, DoCheck {
  name = "Angular";
  html: SafeHtml;

  elementTypes = {
    input: "input",
    multilineinput: "textarea"
  };

  set listenersSink(listener) {
    this._listeners.push(listener);
  }
  _listeners = [];

  willRenderInputs: boolean;

  // @ViewChildren('.dynamic-render') set dynamicRenders(value: QueryList<HTMLElement>) {
  //   console.log('renders', value);
  // }

  constructor(
    private sanitizer: DomSanitizer,
    private el: ElementRef,
    private renderer: Renderer2
  ) {}

  ngOnInit() {
    // this.sanitizer.bypassSecurityTrustHtml(`<input type="text" placeholder="Name" (change)="onChange($event)" [value]="name" />`)
  }

  ngAfterViewInit() {
    const str = `A vector quantity has both magnitude and *1* while a scalar has only magnitude. The value of the acceleration of an object moving at constant velocity is *2*.`;

    const replacedStr = str.replace(
      /\*(.*?)\*/gm,
      `<span class="dynamic-render">input__\$1</span>`
    );

    Promise.resolve().then(() => {
      this.html = this.sanitizer.sanitize(0, replacedStr);
      this.willRenderInputs = true;
    });
  }

  ngDoCheck() {
    if (this.willRenderInputs) {
      Promise.resolve().then(() => {
        const replacements = (this.el
          .nativeElement as HTMLElement).querySelectorAll(".dynamic-render");
        console.log(replacements);
        debugger;

        replacements.forEach((replacement: HTMLElement) => {
          const [elementType, inputName] = replacement.innerText.split("__");
          console.log(elementType, inputName);
          const control: HTMLElement = this.renderer.createElement(
            this.elementTypes[elementType] || "input"
          );
          this.renderer.setAttribute(control, "name", inputName);
          this.listenersSink = this.renderer.listen(
            control,
            "change",
            (...args) => this.onChange(inputName, ...args)
          );
          replacement.innerHTML = null;
          this.renderer.appendChild(replacement, control);
        });
        if (replacements.length) this.willRenderInputs = false;
      });
    }
  }

  ngOnDestroy() {
    this._listeners.forEach(
      listener => typeof listener === "function" && listener()
    );
  }

  onChange(inputName, e) {
    console.log(inputName, e.target.value);
  }
}
