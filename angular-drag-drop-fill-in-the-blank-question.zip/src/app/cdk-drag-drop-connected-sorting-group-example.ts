import { Component } from '@angular/core';
import { CdkDragDrop, transferArrayItem } from '@angular/cdk/drag-drop';
import { QuestionService } from './question.service';
import { QuestionDetails } from './question.constant';

@Component({
  selector: 'cdk-drag-drop-connected-sorting-group-example',
  templateUrl: 'cdk-drag-drop-connected-sorting-group-example.html',
  styleUrls: ['cdk-drag-drop-connected-sorting-group-example.css'],
})
export class CdkDragDropConnectedSortingGroupExample {
  public runApp: boolean;
  constructor(private questionService: QuestionService) {}

  public userData = {
    question: '',
    options: '',
  };

  public questionDetails: QuestionDetails;

  public onsubmit(): void {
    this.questionDetails = this.questionService.processQuestionResponse({
      question: this.userData.question,
      options: this.userData.options.split(','),
    });
    this.runApp = true;
  }

  public onReset(): void {
    this.userData = {
      question: '',
      options: '',
    };
    this.runApp = false;
  }

  public trackByMethod(index: number): number {
    return index;
  }

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      return;
    }

    const allowTheMove = () => {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    };

    const swap = () => {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
      transferArrayItem(
        event.container.data,
        event.previousContainer.data,
        event.currentIndex + 1,
        event.previousIndex
      );
    };

    if (event.container.data.length === 0) {
      allowTheMove();
    } else {
      swap();
    }
  }
}
