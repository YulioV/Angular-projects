import { Injectable } from '@angular/core';
import { QuestionDetails, QuestionDetailsResponse } from './question.constant';

@Injectable({
  providedIn: 'root',
})
export class QuestionService {
  public processQuestionResponse(
    rawResponse: QuestionDetailsResponse
  ): QuestionDetails {
    const questionDetails = {
      questions: rawResponse.question.split('$$_$$'),
      options: rawResponse.options,
      answers: new Array(rawResponse.question.split('$$_$$').length),
    };
    questionDetails.questions.forEach((_quest, i) => {
      questionDetails['answers'][i] = [];
    });

    return questionDetails;
  }
}
